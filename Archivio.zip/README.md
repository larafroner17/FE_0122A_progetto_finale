# CRM

CRM per la gestione di utenti (admin o user), clienti e fatture.



## Come aprire il progetto

* npm i

* npm i bootstrap

* npm i bootstrap-icons
