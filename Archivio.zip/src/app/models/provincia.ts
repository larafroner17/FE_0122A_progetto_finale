export interface Provincia {
  id: number,
  nome: string,
  sigla: string
}
